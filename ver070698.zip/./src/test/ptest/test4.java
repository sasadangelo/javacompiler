/* Test 4:
 *
 * Questo test controlla che 'volatile' e 'transient' siano definite:
 *
 *                       non supportate
 */

public class name {
  transient float field1;
  volatile int field2;
}
