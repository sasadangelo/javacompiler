/* Test 11:
 *
 * Questo test controlla che un metodo e un campo, possono avere lo stesso
 * nome. Cio' puo' verificarsi, perche' essi verranno usati sempre in 
 * circostanze diverse che permettera' di distinguerli.
 */

package packname;

class s1 {
  int pippo;
   
  void pippo() {}  /* corretto!!! */

}

