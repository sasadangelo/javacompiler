/* Test 73:
 *
 * Iniziamo ora a testare i campi di interfacce.
 */

package gimnasium;

interface applet {
  int a=10;

}

public interface view {
  int a=11;

}

interface primax {
  synchronized int a=12;
  native int b=13;
  transient int c=14;
  volatile int d=15;

}

interface mustek {
  protected int a=16;
  private int b=17;
}

interface ariston {
  double a;

}







