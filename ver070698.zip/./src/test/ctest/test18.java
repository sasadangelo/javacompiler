/*
 * Test 18
 *
 * da questo test inizia il test per la generazione di espressioni. Iniziamo da
 * ..?..:..
 */

class HelloWorld {
  static public void main(String[] argv)
  {
    int i=1;
    int l=2;
    int k;

    k=i>l ? 10 : 20;

    System.out.println(k);  // stampo 20.
    
  }
}
