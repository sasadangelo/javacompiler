/*
 * Test 4
 *
 * Istruzione if..then..else la cui espressione e' una variabile boolean.
 */

class HelloWorld 
{
  static public void main(String[] a)
  {
    boolean i=true;

    if (i)
      System.out.println("L'espressione e' vera.");
  }
}

