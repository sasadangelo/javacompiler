/*
 * Test 1
 *
 * questo test come quelli che seguiranno, ci permetteranno di esaminare la
 * correttezza della generazione del codice. Ovviamente il primo test, di
 * obbligo e' il classico HelloWorld.
 */

class HelloWorld 
{
  static public void main(String[] a) 
  {
    System.out.println("HelloWorld");
  }
}
