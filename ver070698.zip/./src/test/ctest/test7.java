/*
 * Test 7
 *
 * Istruzione for. Stampo, in un ciclo infinito il messaggio "Hello World".
 */

class HelloWorld 
{
  static public void main(String[] a)
  {
    for(;;) System.out.println("Hello World");
  }
}

