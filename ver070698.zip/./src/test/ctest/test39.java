/*
 * Test 39
 *
 * Questo test controlla la somma tra stringhe.
 */

class HelloWorld {
  static public void main(String[] argv)
  {
    for (int i=1; i<101; i++)
      for (int j=100; j>0; j--)
	System.out.println("Indici:"+i+","+j);
  }
}
