/*
 * Test 5
 *
 * Istruzione if..then..else la cui espressione e' un valore boolean.
 */

class HelloWorld 
{
  static public void main(String[] a)
  {
    if (true)
      System.out.println("L'espressione e' vera.");
  }
}

