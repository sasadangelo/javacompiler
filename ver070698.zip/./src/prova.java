import java.util.Hashtable;
import java.applet.*;
import java.io.*;
import java.awt.*;
import java.net.*;

class prova extends Applet implements Runnable {
  AudioClip music;

  void g() {
    music.stop();
  }
}
