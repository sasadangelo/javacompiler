/* Test 18:
 *
 * Questo test controlla la deallocazione dalla symbol table dei parametri 
 * formali. 
 */

package packname;

class s1 {
 
  void pippo(int a, int b, int c) {}
  void pluto(int a, int b) {}

}
