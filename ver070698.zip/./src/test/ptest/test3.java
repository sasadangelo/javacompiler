/*
 * Test 3:
 *
 * Si controlla l'errore che deve essere inviato quando si omette la keyword 
 * CLASS.
 * Il Parser fa in modo che tale keyword venga considerata.
 */

package pippo;

public   
nomeclasse {
  int a;

  void s() {}
}

