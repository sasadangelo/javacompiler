/* Test 74:
 *
 * Testare i metodi delle interfacce.
 */

package gimnasium;

interface applet {

void pippo (int i);

}

public interface view {

void applet (int i);

}

public interface graph {

native void applet (int i);
protected int gigi();
synchronized float renoir();

}







