/* Test 51:
 *
 * Istruzione do .. while 
 */

package gimnasium;

class s1 {
  void pippo() 
   {
	int var1, var2;

	do { } while (true) ;

	do if (true); while (var1 > var2);

	do { } while (var1);     // errore!!! var1 e' di tipo int.
   }
}







