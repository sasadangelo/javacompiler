/*
 * Test 8
 *
 * Istruzione do..while. Stampo i numeri da 0 a 9.
 */

class HelloWorld 
{
  static public void main(String[] a)
  {
    int i=0;

    do {
      System.out.println(i);
      ++i;
    } while (i<10);
  }
}

