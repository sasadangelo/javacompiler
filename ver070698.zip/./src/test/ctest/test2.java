/*
 * Test 2
 *
 * Iniziamo con il dichiarare un campo in una class e stamparne il valore.
 */

class HelloWorld 
{
  static int field;
  static int field1=3;

  static public void main(String[] a)
  {
    field=5;
    System.out.println(field);
    System.out.println(field1);
  }
}
