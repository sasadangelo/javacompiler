/* Test 78:
 *
 * Controlliamo che venga introdotto il costruttore di default, nel caso in cui
 * non vengono definiti costruttori all'interno di una classe.
 */


/*
 * JVM da un segmantation fault.
 */
	 	
package gimnasium;

class minni {

float j;

int cane() {}                

}







