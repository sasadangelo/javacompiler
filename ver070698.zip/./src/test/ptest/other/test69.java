/* Test 80:
 *
 * In questo test verificheremo la corretta compilazione di Expression 
 * Statement.
 */

package gimnasium;

class pluto {}

class minni
{
  void cake() {}

  void meth()
  {
    int i;
    
    i=1;
    i++;
    ++i;
    i--;
    --i;
    new pluto();
    cake();
    
    
  }
}
