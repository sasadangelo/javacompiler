/* Test 8:
 *
 * Questo test controlla che una class non sia private e non sia contempora-
 * neamente abstract e final.
 */

package packname;

private class classname {
}

abstract final public class notaro {
}
