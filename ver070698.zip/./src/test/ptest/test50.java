/* Test 50:
 *
 * Istruzione while .. do 
 */

package gimnasium;

class s1 {
  void pippo() 
   {
     int var1, var2;
     
     while (true) ;

     while (var1);          // errore!!! var1 non e' boolean.
     
     while (var1 > var2) 
       if (true);
     
   }
}







