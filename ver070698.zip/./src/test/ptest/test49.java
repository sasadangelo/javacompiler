/* Test 49:
 *
 * Iniziamo ora il test delle istruzioni.
 *
 * Istruzione if .. then 
 *            if .. then .. else
 */

package gimnasium;

class s1 {
  void pippo() 
   {
	int var1, var2;

	if (10 > 11) 
	  if (var1 > var2);

	if (var1);             // errore!!! var1 non e' boolean.

	if (true) { } else { }
   }
}







