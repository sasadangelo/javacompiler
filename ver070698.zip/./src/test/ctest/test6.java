/*
 * Test 6
 *
 * Istruzione while e uso di variabili locali. Stampo i numeri da 0 a 9.
 */

class HelloWorld 
{
  static public void main(String[] a)
  {
    int i=0;

    while (i<10) 
      {
	System.out.println(i);
	++i;
      }
  }
}

